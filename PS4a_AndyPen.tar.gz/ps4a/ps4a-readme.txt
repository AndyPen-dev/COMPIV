﻿/**********************************************************************
 *  readme.txt template                                                   
 *  Synthesizing a Plucked String Sound:
 *  CircularBuffer implementation with unit tests and exceptions 
 **********************************************************************/

Name: Andy Pen 


Hours to complete assignment: 4 hours 

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

This assignment implements a circular buffer array and uses boost test cases to test the functions. 
 **********************************************************************/





/**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.

For this assignment I ended up using an array to create and implement the circular buffer array. I also used a smart pointer so that I wouldn’t have to free any data. The array was helpful since the data can be accessed with a front and rear.  
 **********************************************************************/





/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.

I created private members for the size, capacity, front, rear, and an array to initialize the buffer array. I had to initialize those members to zero in the constructor and create an empty buffer with the capacity. I also kept track of the size within the enqueue function and dequeue functions where in the enqueue I did buffSize++ and dequeue function I did buffSize--. To check if the buffer is empty I compared buffSize to zero and to check if it is full I checked if buffSize was equal to the buffCap. 
 **********************************************************************/





/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.

I completed the assignment and got the test cases to pass. I think all of the functions are working correctly, because I had to fix some when I was running the unit tests. I also did the cpp lint to check for errors in the cpp files. 
 **********************************************************************/





/**********************************************************************
 *  Does your CircularBuffer implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.

The CircularBuffer implementation passes the unit tests because it tests all of the functions in which it enqueues and dequeues data, as well as checks if the it is full or empty. 
 **********************************************************************/





/**********************************************************************
 *  Explain the time and space performance of your RingBuffer
 *      implementation

The time and space complexity for the implementation of the Ring Buffer will be O(1)  because there was no resizing done. 
 **********************************************************************/





/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.

I read an article on circular buffers for a better understanding “https://en.wikipedia.org/wiki/Circular_buffer”
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.   

I was having trouble with my isEmpty function when I was trying to run the test cases, but then I ended up realizing I didn’t initialize the buffSize to zero in the constructor.                 
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                   

My exexutable is ps4a                  
 **********************************************************************/


