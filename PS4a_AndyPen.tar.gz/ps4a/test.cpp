// (C) Copyright Andy Pen, 2021.
#include "CircularBuffer.h"
#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(firstTestCase) {
CircularBuffer CB(7);
BOOST_REQUIRE(CB.isEmpty());

CB.enqueue(8);
CB.enqueue(3);
CB.enqueue(1);
BOOST_REQUIRE_EQUAL(CB.dequeue(), 8);
BOOST_REQUIRE_EQUAL(CB.dequeue(), 3);
BOOST_REQUIRE_EQUAL(CB.dequeue(), 1);
}

BOOST_AUTO_TEST_CASE(secondTestCase) {
CircularBuffer CB(5);
BOOST_REQUIRE_THROW(CB.dequeue(), std::runtime_error);
}

BOOST_AUTO_TEST_CASE(thirdTestCase) {
CircularBuffer CB(10);

BOOST_REQUIRE_NO_THROW(CB.enqueue(5));
}
