// (C) Copyright Andy Pen, 2021.

#include "CircularBuffer.h"

CircularBuffer::CircularBuffer(int capacity) {
// create an empty ring buffer, with given max capacity
    front = 0;
    rear = 0;
    buffSize = 0;
    buffCap = capacity;
    if (buffCap <= 0) {
        throw std::invalid_argument("capacity must be greater than zero.");
    }
    // create buffer ring
    arr = std::make_unique<std::int16_t[]> (buffCap);
}

int CircularBuffer::size() {
// return number of items currently in the buffer
    return buffSize;
}

bool CircularBuffer::isEmpty() {
// is the buffer empty (size equals zero)?
    return (buffSize == 0);
}

bool CircularBuffer::isFull() {
// is the buffer full (size equals capacity)?
    return (buffSize == buffCap);
}


void CircularBuffer::enqueue(int16_t x) {
// add item x to the end
    if (isFull()) {
        throw std::runtime_error("can't enqueue to a full ring");
    } else {
        arr[rear] = x;
        rear = (rear +1) % buffCap;
        // increment size of buffer
        buffSize++;
    }
}

int16_t CircularBuffer::dequeue() {
// delete and return item from the front
    if (isEmpty()) {
        throw std::runtime_error("Buffer is empty.");
    }
    auto temp = arr[front];
    front = (front + 1) % buffCap;
    // decrement size of buffer
    buffSize--;
    return temp;
}

int16_t CircularBuffer::peek() {
// return (but do not delete) item from the front

    if (isEmpty()) {
        throw std::runtime_error("Buffer is empty.");
    }
    return arr[front];
}
