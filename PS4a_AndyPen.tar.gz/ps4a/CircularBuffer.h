// (C) Copyright Andy Pen, 2021.
#include <iostream>
#include <stdint.h>  // defines standard 16-bit integer type int16_t.
#include <memory>
#include <stdexcept>

class CircularBuffer {
 public:
    CircularBuffer(int capacity);
    int size();
    bool isEmpty();
    bool isFull();
    void enqueue(int16_t x);
    int16_t dequeue();
    int16_t peek();

 private:
    int front;
    int rear;
    int buffCap;
    int buffSize;
    std::unique_ptr<std::int16_t[]> arr;
};
