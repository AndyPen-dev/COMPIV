﻿ps2a
I got the planets to display after fixing the positions of the planets. I also made sure to pass the cpplint test. 

ps2b
After getting the planets to display I added a step and printBody function to display the planet’s moving and display the times. I had to use the force formulas to make sure each planet revolved around in counter clockwise direction and the sun was fixated at the center of the window. I also made sure to pass the cpplint test.
