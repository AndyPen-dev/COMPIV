﻿/**********************************************************************
 *  Linear Feedback Shift Register (part A) ps1a-readme.txt template
 **********************************************************************/

Name: Andy Pen
Hours to complete assignment: 6-7 hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

This assignment used a bit shift register to XOR each tap bit, shift the bits and add the resulting bit. The step function was used to change the first bit into the new bit that was created by XOR the taps. Then the generate function was used to get the results of steps based on the k bits and adding it to the result bit. 

 **********************************************************************/





/**********************************************************************
 *  Explain the representation you used for the register bits 
 *  (how it works, and why you selected it)

I used std::bitset to represent the bits because I felt that it would be easier and more efficient to use rather than creating an array or vector and destructors. 
I initialized the bit set in the constructor and then for the step function I had to create a new bit that used the initial bit set to create a new one that is calculated by XOR each of the taps. For the generate function I used a for loop that loops through k bits and returned the result after calling the step function. 
 **********************************************************************/


 
/**********************************************************************
 * Discuss what's being tested in your two additional Boost unit tests

In my Boost unit test I made a test that checked if the ostream << operator worked so I outputted a string bit as a test. 
  **********************************************************************/





/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.

I used the professor’s lecture videos for help on understanding how the LFSR works
 **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered. 

I had trouble creating the Makefile at first and had to keep fixing it because of spacing and capitalization                   
 **********************************************************************/


/**********************************************************************
 *  List any other comments here. 
In the Makefile, I used the given Makefile as a template and included all of the files used.                                     
 **********************************************************************/

