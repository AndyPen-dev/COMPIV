/*
Andy Pen
Dr.Rykalova
Due 2/8/21
*/
#include <iostream>
#include <string>
#include <bitset>

class FibLFSR{

public:
	FibLFSR(const std::string& seed); //constructor to create LFSR with
				//the given initial seed and tap

	int step();		// simulate one step and return the
				// new bit as 0 or 1

	int generate(int k);	// simulate k steps and return
				// k-bit integer
	friend std::ostream& operator <<(std::ostream& lhs, const FibLFSR& rhs); 
       	//Overload the << stream insertion operator to display its
	//current register value in printable form
	       			
private: 
	std::bitset<16> value; 

};


