#include "ED.h"
#include <SFML/System.hpp> 

int main(int argc, char* argv[]){
    //read in 2 stirngs
    std::string str1; 
    std::string str2; 
    std::cin >> str1; 
    std::cin >> str2; 

    sf::Clock clock; 
    sf::Time t; 

    ED ed(str1, str2); 

    //display edit distance 
    int editDistance; 
    editDistance = ed.OptDistance(); 

    std::cout << "Edit Distance = " << editDistance << std::endl; 

    std::cout << ed.Alignment(); 
//end of main, after computing solution, capture running time
    t = clock.getElapsedTime(); 
    
//display running time
    std::cout << "Execution time is " << t.asSeconds() << " seconds \n"; 

    return 0; 
}