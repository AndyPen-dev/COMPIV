#include <iostream> 
#include <string> 
#include <stdlib.h> 
#include <vector>
#include <sstream>

class ED{
public:
    ED(std::string x, std::string y); 
    int penalty(char a, char b);
    int min(int a, int b, int c);
    int OptDistance();
    std::string Alignment(); 

private:
    std::string X; 
    std::string Y;
    std::vector <std::vector<int>> matrix; 
    
}; 