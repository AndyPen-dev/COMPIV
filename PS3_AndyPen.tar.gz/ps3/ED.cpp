#include "ED.h"
#include <algorithm>

ED::ED(std::string x, std::string y){
   //accept 2 strings to be compared 
    //allocate any data structures
    X = x;  
    Y = y;
    //make sure there is enough space 
    matrix = std::vector <std::vector<int>> ((int)X.length() +1); 
    for(int i =0; i <= (int)X.length(); i++){
        matrix[i] = std::vector<int>((int)Y.length() + 1); 
    }
    
}


int ED::penalty(char a, char b){
    //return the penalty for aligning chars a and b (0 or 1)
    if(a == b){
        return 0;
    }
    else{
        return 1; 
    }
   
}

int ED::min(int a, int b, int c){
    //return the minimum of three arguments 
    return std::min({a,b,c}); //included in <algorithm> 

}

int ED::OptDistance(){
    //populates matrix based on two strings
    //return optimal distance 
    int M; //rows
    int N; //columns 
    M = X.length(); 
    N = Y.length(); 

    for(int i = 0; i <= M; i++){
        for(int j = 0; j <= N; j++){
            matrix[M][j] = 2 * (N-j); 
        }
        matrix[i][N] = 2 * (M-i); 
    }

    for(int i = M - 1; i >= 0; i--){
        for(int j = N - 1; j >= 0; j--){
            matrix[i][j] = min(matrix[i+1][j+1] + penalty(X[i], Y[j]), matrix[i+1][j] + 2, matrix[i][j+1] + 2); 
        }
    }


    //return optimal distance at matrix[0][0]
    return matrix[0][0]; 
}

std::string ED::Alignment(){
    //traces matrix

    //use string stream to read in string as stream
    std::stringstream output; 

    int newX; 
    int newY; 
    newX = X.length(); 
    newY = Y.length();

    int i = 0; 
    int j = 0; 
  
//create table
//end gap = 2
// match = 0
//mismatch = 1
// retrace from from opt[0][0] to opt[M][N]
    while(i < newX && j < newY){
        if(matrix[i][j] - 2 == matrix[i][j+1]){
            output << "- " << Y[j] << " 2" << std::endl; 
            j++; 
        }
        else if(matrix[i][j] - 2 == matrix[i+1][j]){
            output << X[i] << " - 2" << std::endl; 
            i++; 
        }
        else if(matrix[i][j] - 1 == matrix[i+1][j+1]){
            output << X[i] << ' ' << Y[j] << " 1" << std::endl; 
            i++; 
            j++; 
        }
        else{
            output << X[i] << ' ' << Y[j] << " 0" << std::endl; 
            i++; 
            j++; 
        }
    }

    if(i < newX){
        output << X[i+1] << " - 2" << std::endl; 
    }
    else if(j < newY){
        output << "- " << Y[j+1] << " 2" << std::endl; 
    }

 
    //return string that can be printed to display actual alignment
    return output.str(); 


}