﻿/**********************************************************************
 *  readme.txt template                                                   
 *  PS6 Kronos 
 **********************************************************************/

Name: Andy Pen


Hours to complete assignment: 4 hours


/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.

Assignment was completed and was successful. All parts are working since the rpt for each device login was made successfully. 
 **********************************************************************/



/**********************************************************************
 *  Copy here all regex's you created for parsing the file, 
 *  and explain individually what each ones does.

    std::string s_date("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ");
    std::string s_time("([0-9]{2}):([0-9]{2}):([0-9]{2})");
    std::string s_boot("(.*log.c.166.*)");
    std::string s_end("(.*oejs.AbstractConnector:Started SelectChannelConnector.*)");
Regexs was made with each string above to detect the boots and find the matching time and dates.

    regex r_boot(s_date + s_time + s_boot);
    regex r_end(s_date + s_time + s_end);
Regex r_boot and r_end was used for parsing the file.
 **********************************************************************/



/**********************************************************************
 *  Describe your overall approach for solving the problem.
 *  100-200 words.

First read in the InTouch logs and reports given and see whether or not each one started up, or whether it failed. If the boot was completed then keep track of the time it took to complete and put everything inside a textfile report.
 **********************************************************************/




/**********************************************************************
 *  Did you use lambda expression? If yes describe there.
 **********************************************************************/





/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.

Professor's lecture
regex match sample code
boost_regex docs
boost_time docs
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.    
 I had trouble with the makefile and forgot to include -lboost_regex and   
-lboost_date_time          
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/



