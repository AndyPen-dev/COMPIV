// Copyright Andy Pen 2021
#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>

#include <boost/regex.hpp>
#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"

using boost::regex;
using boost::gregorian::date;
using boost::gregorian::from_simple_string;

using boost::posix_time::ptime;
using boost::posix_time::time_duration;

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cout << "Error" << std::endl;
    }
    std::ifstream inputFile(argv[1], std::ifstream::in);
    if (!inputFile.is_open()) {
        std::cout << "Failed to open file. " << std::endl;
        return 0;
    }

    std::string fileName(std::string(argv[1]) + ".rpt");
    std::ofstream output;
    output.open(fileName.c_str());

    std::string s_date("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2}) ");
    std::string s_time("([0-9]{2}):([0-9]{2}):([0-9]{2})");
    std::string s_boot("(.*log.c.166.*)");
    std::string s_end("(.*oejs.AbstractConnector:Started SelectChannelConnector.*)");//NOLINT
    boost::smatch match;

    regex r_boot(s_date + s_time + s_boot);
    regex r_end(s_date + s_time + s_end);

  // Check if boot is successful
    std::string s;
    int line;
    line = 1;
    bool state = false;
    ptime t1;
    ptime t2;

    while (getline(inputFile, s)) {
        if (regex_match(s, match, r_boot)) {
            if (state) {
                output << "Boot Failed \n\n";
            }
      date d1(from_simple_string(match[0]));
      ptime temp(d1, time_duration(std::stoi(match[4]), std::stoi(match[5]), std::stoi(match[6])));//NOLINT
      t1 = temp;

      output << "Booting Device" << std::endl;
      output << line << "(" << argv[1] << "): ";
      output << match[1] << "-" << match[2] << "-" << match[3] << " ";
      output << match[4] << ":" << match[5] << ":" << match[6] << " ";
      output << "Boot Start" << std::endl;
      state = true;

    } else if (regex_match(s, match, r_end)) {
      if (state) {
        date d2(from_simple_string(match[0]));
        ptime temp(d2, time_duration(std::stoi(match[4]), std::stoi(match[5]), std::stoi(match[6])));//NOLINT
        t2 = temp;

        time_duration td;
        td = t2 - t1;

        output << line << "(" << argv[1] << "): ";
        output << match[1] << "-" << match[2] << "-" << match[3] << " ";
        output << match[4] << ":" << match[5] << ":" << match[6] << " ";
        output << "Boot Completed" << std::endl;

        output << "Time: ";
        output << td.total_milliseconds() << "ms \n\n";

        state = false;
      } else {
        output << "Unknown Boot\n\n";
      }
    }
    line++;
  }
  return 0;
}
