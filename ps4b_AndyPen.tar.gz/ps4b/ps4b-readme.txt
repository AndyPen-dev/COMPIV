﻿/**********************************************************************
 *                                                  
 *  PS4b: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Andy Pen

Hours to complete assignment : 6-7

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.

I was able to complete most of the assignment. I am just trying to figure out to get the sound to work. Everything compiles but there is no sound. 
 **********************************************************************/



/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  

No 
 **********************************************************************/


/**********************************************************************
 *  Did you implement exceptions to check your StringSound 
 *      implementation?
 *  Indicate yes or no, and explain how you did it.

Yes, I did in the constructors if the capacity was less than 0 or negative. 
 **********************************************************************/



/**********************************************************************
 *  Did you implement lambda expression?
 *  Indicate yes or no, and explain how you did it.

No 
 **********************************************************************/



/**********************************************************************
 *  Did your code pass cpplint?
 *  Indicate yes or no, and explain how you did it.

Yes I had to replace a lot of tabs with spaces and made sure to not have any extra white spaces. 
 **********************************************************************/


/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.

Lecture notes 
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.   

I was getting seg fault with the starter code. I had to make the samples function pass by reference std::vector<sf::Int16> makeSamplesFromString(StringSound& gs)                  
 **********************************************************************/


/**********************************************************************
 *  List any other comments here.                                     
 **********

