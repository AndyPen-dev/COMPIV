// (C) Copyright Andy Pen, 2021.
#ifndef _HOME_VISOTHPEN_COMP2040_PS4B_CIRCULARBUFFER_H_
#define _HOME_VISOTHPEN_COMP2040_PS4B_CIRCULARBUFFER_H_
#include <iostream>
#include <stdint.h>  // defines standard 16-bit integer type int16_t.
#include <memory>
#include <stdexcept>

class CircularBuffer {
 public:
    explicit CircularBuffer(int capacity);
    int size();
    bool isEmpty();
    bool isFull();
    void enqueue(int16_t x);
    int16_t dequeue();
    int16_t peek();

 private:
    int front;
    int rear;
    int buffCap;
    int buffSize;
    std::unique_ptr<std::int16_t[]> arr;
};
#endif  // _HOME_VISOTHPEN_COMP2040_PS4B_CIRCULARBUFFER_H_
