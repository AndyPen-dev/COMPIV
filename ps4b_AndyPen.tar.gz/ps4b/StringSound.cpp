// (C) Copyright Andy Pen, 2021.
#include "StringSound.h"
#include "CircularBuffer.h"
constexpr unsigned sample_rate = 44100;
StringSound::StringSound(double frequency) {
// create a guitar string sound of the
// given frequency using a sampling rate of 44,100
    _time = 0;
    int length;
    if (frequency <= 0) {
        throw std::invalid_argument("Capacity must be greater than zero.");
    } else {
        length = ceil(sample_rate / frequency);
        _cb = new CircularBuffer(length);
        while (!_cb->isFull()) {
            _cb->enqueue(0);
        }
    }
}

StringSound::StringSound(std::vector<sf::Int16> init) {
// create a guitar string with size and initial values given by vector
    _time = 0;
    int count;
    if (init.size() <= 0) {
        throw std::invalid_argument("Capacity must be greater than zero.");
    } else {
        _cb = new CircularBuffer(init.size());
        count = 0;
        while (!_cb->isFull()) {
            _cb->enqueue(init[count]);
            count++;
        }
    }
}

StringSound::~StringSound() {}

void StringSound::pluck() {
// pluck the guitar string by replacing buffer w/ random values
// representing white noise
    if (_cb->isFull()) {
        for (int i = 0; i < _cb->size(); i++) {
            _cb->dequeue();
        }
    }
    while (_cb->isFull()) {
        _cb->enqueue((sf::Int16)(rand() * 0xffff)); //NOLINT
    }
}

void StringSound::tic() {
// advance the simulation one time step
    sf::Int16 tic;
    tic = 0.5 * 0.996 * (_cb->dequeue() + _cb->peek());
    _cb->enqueue(tic);
    _time++;
}

sf::Int16 StringSound::sample() {
// return the current sample
    return _cb->peek();
}

int StringSound::time() {
// return number of times tic was called so far
    return _time;
}
