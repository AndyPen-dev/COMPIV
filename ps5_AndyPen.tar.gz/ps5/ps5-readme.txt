﻿/**********************************************************************
 *  ps5-readme 
 *  Recursive Graphics (Triangle Fractal)                       
 **********************************************************************/

Your name: Andy Pen 

Hours to complete assignment: 3 hours

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

This assignment uses a recursive function and takes two command line arguments to draw and output Sierpinksi’s triangles within a SFML window. I also used the cpplint to check the style of the code.
 **********************************************************************/



 /**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.

Using recursion was central to this assignment since it was needed to repeatably draw the triangles.
 **********************************************************************/



/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.

In the TFractal class, I created the triangle based on the constructor with the three points and then set the color with the function I made to set the triangle’s color and then recursively drew the triangle based on the input. 
Triangle triangle(pt1, pt2, pt3);
triangle.setColorBlue();
window.draw(triangle);
if (size < depth) {
TFractal(size + 1, depth,
sf::Vector2f((pt1.x + pt2.x) / 2 + (pt2.x - pt3.x) / 2,
(pt1.y + pt2.y) / 2 + (pt2.y - pt3.y) / 2),
sf::Vector2f((pt1.x + pt2.x) / 2 + (pt1.x - pt3.x) / 2,
(pt1.y + pt2.y) / 2 + (pt1.y - pt3.y) / 2),
sf::Vector2f((pt1.x + pt2.x) / 2, (pt1.y + pt2.y) / 2),
window);



 **********************************************************************/



 /**********************************************************************
 *  Briefly explain what you learned in the assignment.

In this assignment, I learned how to incorporate recursion to draw Triangles and I also learned how to use the SFML feature vertex array. 
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.

Instructor’s readings and videos, SFML features 
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.  
 *  If you didn't complete any part of any assignment, 
 *  the things that you didn't do, or didn't get working.    

I had trouble drawing the triangle at first until I looked at how to draw a triangle on the SFML website          
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.         

To run the code I tested it with 
./TFractal 5 500                            
 **********************************************************************/

