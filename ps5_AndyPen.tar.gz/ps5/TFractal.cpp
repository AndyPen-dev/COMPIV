// Copyright Andy Pen
#include "Triangle.h"
#include <SFML/System.hpp>
#include <SFML/Window.hpp>

// draw base triangle
void drawBase(int depth, int height, sf::RenderWindow &window); //NOLINT
// recursive function
void TFractal(int n, int depth, sf::Vector2f pt1, sf::Vector2f pt2, sf::Vector2f pt3, sf::RenderWindow &window); //NOLINT

int main(int argc, char *argv[]) {
  int N = std::stoi(argv[1]);
  double L = std::stod(argv[2]);

  sf::RenderWindow window(sf::VideoMode(L, L), "Sierpinski's Triangle");
  while (window.isOpen()) {
    sf::Event event;
    while (window.pollEvent(event)) {
      if (event.type == sf::Event::Closed) {
        window.close();
      }
    }

    drawBase(N, L, window);
    window.display();
  }

  return 0;
}

void drawBase(int n, int l, sf::RenderWindow &window) { //NOLINT
  sf::Vector2f pt1(l / 2, 0);
  sf::Vector2f pt2(0, l);
  sf::Vector2f pt3(l, l);

  Triangle triangle(pt1, pt2, pt3);
  window.draw(triangle);

  TFractal(1, n,
    sf::Vector2f((pt1.x + pt2.x) / 2, (pt1.y + pt2.y) / 2),
    sf::Vector2f((pt1.x + pt3.x) / 2, (pt1.y + pt3.y) / 2),
    sf::Vector2f((pt2.x + pt3.x) / 2, (pt2.y + pt3.y) / 2),
    window);
}

void TFractal(int size, int depth, sf::Vector2f pt1, sf::Vector2f pt2, sf::Vector2f pt3, sf::RenderWindow &window) { //NOLINT
  Triangle triangle(pt1, pt2, pt3);
  triangle.setColorBlue();
  window.draw(triangle);

    if (size < depth) {
        TFractal(size + 1, depth,
        sf::Vector2f((pt1.x + pt2.x) / 2 + (pt2.x - pt3.x) / 2,
        (pt1.y + pt2.y) / 2 + (pt2.y - pt3.y) / 2),
        sf::Vector2f((pt1.x + pt2.x) / 2 + (pt1.x - pt3.x) / 2,
        (pt1.y + pt2.y) / 2 + (pt1.y - pt3.y) / 2),
        sf::Vector2f((pt1.x + pt2.x) / 2, (pt1.y + pt2.y) / 2),
        window);

        TFractal(size + 1, depth,
        sf::Vector2f((pt3.x + pt2.x) / 2 + (pt2.x - pt1.x) / 2,
        (pt3.y + pt2.y) / 2 + (pt2.y - pt1.y) / 2),
        sf::Vector2f((pt3.x + pt2.x) / 2 + (pt3.x - pt1.x) / 2,
        (pt3.y + pt2.y) / 2 + (pt3.y - pt1.y) / 2),
        sf::Vector2f((pt3.x + pt2.x) / 2, (pt3.y + pt2.y) / 2),
        window);

        TFractal(size + 1, depth,
        sf::Vector2f((pt1.x + pt3.x) / 2 + (pt3.x - pt2.x) / 2,
        (pt1.y + pt3.y) / 2 + (pt3.y - pt2.y) / 2),
        sf::Vector2f((pt1.x + pt3.x) / 2 + (pt1.x - pt2.x) / 2,
        (pt1.y + pt3.y) / 2 + (pt1.y - pt2.y) / 2),
        sf::Vector2f((pt1.x + pt3.x) / 2, (pt1.y + pt3.y) / 2),
        window);
    }
}
