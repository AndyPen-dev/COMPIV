// Copyright Andy Pen
#include <iostream>
#include <SFML/Graphics.hpp>
#include <cstdlib>//NOLINT
#include <string>//NOLINT
#ifndef _HOME_VISOTHPEN_COMP2040_PS5_TRIANGLE_H_
#define _HOME_VISOTHPEN_COMP2040_PS5_TRIANGLE_H_

class Triangle : public sf::Drawable {
 public:
  Triangle(const sf::Vector2f& pt1, const sf::Vector2f& pt2, const sf::Vector2f& pt3);//NOLINT
  void draw(sf::RenderTarget& target, sf::RenderStates states) const;//NOLINT
  void setColorBlue();

 private:
  sf::VertexArray point;
};

#endif  // _HOME_VISOTHPEN_COMP2040_PS5_TRIANGLE_H_
