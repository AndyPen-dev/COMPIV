// Copyright Andy Pen
#include "Triangle.h"
#include <math.h>

Triangle::Triangle(const sf::Vector2f& pt1, const sf::Vector2f& pt2, const sf::Vector2f& pt3) { //NOLINT
  point = sf::VertexArray(sf::Triangles, 3);
  point[0].position = pt1;
  point[1].position = pt2;
  point[2].position = pt3;
}

void Triangle::setColorBlue() {
  point[0].color = sf::Color::Blue;
  point[1].color = sf::Color::Blue;
  point[2].color = sf::Color::Blue;
}

void Triangle::draw(sf::RenderTarget& target, sf::RenderStates states) const {
  target.draw(point);
}
