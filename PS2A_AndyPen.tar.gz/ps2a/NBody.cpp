#include "universe.h"

//main file that manually creates a Body object, by copying initialization parameters from
//the planets.txt file into your source code
int main(int argc, char* argv[]){

    int numBodies; 
    double radius; 
    std::cin >> numBodies >> radius;

    Universe universe(numBodies, radius); 

    int dimension;     
    dimension = radius * 2; 
    sf::RenderWindow window(sf::VideoMode(dimension,dimension), "Universe");

    while(window.isOpen()){
        sf::Event event; 
        while(!window.pollEvent(event)){
            if(event.type == sf::Event::Closed)
                window.close();
        }
        window.clear(); 
      
       
       // universe.draw(universe); 
       
        window.display();
        
    }
    return 0; 
}

