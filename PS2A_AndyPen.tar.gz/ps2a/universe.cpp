#include "universe.h"


CelestialBody::CelestialBody(){} //default constructor

CelestialBody::CelestialBody(double x, double y, double vX, double vY, double bodyMass, std::string imgFile){
// specify all the initial parameters (x,y position and velocity; mass; image filename)
    
    xPos = x; 
    yPos = y;
    xVel = vX; 
    yVel = vY; 
    mass = bodyMass; 
    img = imgFile; 

//load image into new Texture object;create a new Sprite w Texture 
    texture.loadFromFile(img);
  
}


void CelestialBody::spritePos(double viewScale){

   
    sprite.setTexture(texture); 
    xPos /= 1000000000.0;
    yPos /= 1000000000.0; 
    sprite.setPosition((xPos + viewScale), yPos + viewScale);

}

void CelestialBody::draw(sf::RenderTarget& target, sf::RenderStates states) const{
     
    target.draw(sprite, states); 

}

std::istream &operator>>(std::istream& in, CelestialBody& rhs){
    //read in all member variables
    in >> rhs.xPos >> rhs.yPos >> rhs.xVel >> rhs.yVel >>  rhs.mass >> rhs.img;
    return in; 
}



Universe::Universe(int planets, double rad){

    bodies = planets; 
    radius = rad; 
     
 }

void Universe::newCBody(){

for(int i = 0; i < bodies; i++){
    std::shared_ptr<CelestialBody> ptr(new CelestialBody);
    std::cin >> *ptr; 
    sPtr.push_back(ptr);
}

}


    


