﻿/**********************************************************************
 *  N-Body Simulation ps2a-readme.txt template
 **********************************************************************/

Name: Andy Pen
Hours to complete assignment: 7 hours

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

This assignment involves reading in a universe file and displaying the planets in the window. The program used SFML features with two classes name CelestialBody and Universe where celestial body class is meant to be drawable and take in the data while the universe class create celestial bodies. 
 **********************************************************************/


  /**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.

Operator overloading was central to the assignment because it used cin to read in the data from the file. 
 **********************************************************************/





/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Describe if and how do you used the smart pointers 
 *  Include code excerpts.

In CelestialBody class I made a constructor with parameters 
double x, double y, double vX, double vY, double bodyMass, std::string imgFile
and initialized each member and then loaded the image to the texture. 

I also had a function to update the sprite position by settign the texture to the sprite and setting the position with the xPos and yPos. 

The draw function uses render and targers so that it can be implemented in the Celestial Body class. 

The istream overload operator functions reads in each member value and returns them. 

The Universe cBody function is meant to utilize the smart pointer to share data with the Celestial body class in which the Universe function is supposed to read in the data from the file. 

 **********************************************************************/




/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.

Used notes about smart pointers. 
 **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered. 

  I’m having trouble using the pointers as of right now and displaying the planets onto the screen. 
 **********************************************************************/


/**********************************************************************
 *  List any other comments here.     

This assignment is incomplete as of right now, I’m submitting this version to have the 24 hour grace period since I need more time to work on this.                                 
 **********************************************************************/

