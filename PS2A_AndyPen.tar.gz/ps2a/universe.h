#include <iostream>
#include <stdlib.h>
#include <string>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>


class CelestialBody : public sf::Drawable{
public:
    CelestialBody(); 
    CelestialBody(double x, double y, double xV, double xY, double bodyMass, std::string imgFile);
    void spritePos(double viewScale);

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const; 

    friend std::istream &operator>>(std::istream& in, CelestialBody& rhs);

private:
    double xPos; 
    double yPos;
    double xVel; 
    double yVel; 
    double mass; 
    std::string img; 
    
    sf::Sprite sprite;
    sf::Texture texture;
};

class Universe{
public:
    Universe(int planets, double rad);
    void newCBody();
    

    std::vector<std::shared_ptr<CelestialBody>> sPtr; 
private:
    int bodies; 
    double radius; 
    
};  