﻿/**********************************************************************
 *  Linear Feedback Shift Register (part B) ps1b-readme.txt template
 **********************************************************************/

Name: Andy Pen

Hours to complete assignment: 5-6 hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
This assignment utilized the code from ps1a to encrypt an input file and to restore the file. The point of this assignment was to load a file, manipulate its pixels, and save it. I basically used the same code for FibLFSR.h and FibLFSR.cpp and updated the Makefile. For the PhotoMagic.cpp, I implemented the transform function similarly to how the example code was in pixel.cpp. 




/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
I didn’t do the extra credit. 



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
I used the instructor’s pixel.cpp as a reference to load a file and to manipulate its pixels. 


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
A problem I encountered was when I tried writing ./PhotoMagic output-file.png input-file.png 1011011000110110 in the terminal, but it wasn’t reading in the files and bits. I had to load the file into a string. 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
In the Makefile, I kept mostly everything the same from ps1a, but deleted the boost libraries and added the sfml libraries. I also took out test and added PhotoMagic to the executable after typing make clean in terminal. 

