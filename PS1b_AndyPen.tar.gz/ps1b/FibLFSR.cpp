#include "FibLFSR.h"
#include <stdlib.h>
#include <stdio.h> 
using namespace std;

FibLFSR::FibLFSR(const std::string &seed) : value{seed} {}

int FibLFSR::step(){// simulate one step and return the
                                // new bit as 0 or 1
      
    int newBit = value[15] ^ value[13] ^ value[12] ^ value[10]; 
    //shift value
    value = value << 1;

    value[0] = newBit; 

    return newBit;
  

}            
				
int FibLFSR::generate(int k){// simulate k steps and return
                                // k-bit integer
    int retVal = 0; 
    int newVal = 0; 
    for(int i = 0; i < k; i++){
        
        newVal = step(); 
        retVal = (retVal *2) + newVal; //double the return value and add the newvalue after calling step function 
        
    }
    return retVal; 

}   				 
 std::ostream& operator <<(std::ostream& out, const FibLFSR& rhs){

     out << rhs.value; 
     return out; 

}



