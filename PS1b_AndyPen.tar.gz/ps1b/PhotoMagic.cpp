/*
Andy Pen
COMP2040 
Dr.Rykalova
2/15/2021
*/
#include "FibLFSR.h"
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace std; 

void transform(sf::Image& image, FibLFSR* fib);

// display an encrypted copy of the picture, using the LFSR
// to do the encryption
int main(int argc, char* argv[]){

    //read in filenames and string bit
    string str = argv[3]; 
    string str2 = argv[1]; 
    string str3 = argv[2]; 

    sf::Image image; 
    sf::Image image2; 
    if(!image.loadFromFile(str2)){
        return -1; 
    }
    if(!image2.loadFromFile(str2)){
        return -1; 
    }
    //create Fib pointer to read in third argument of string bits
    FibLFSR *ptr = new FibLFSR(str);
    //call transform function to encrypt source file 
    transform(image2, ptr);
    delete ptr; 

    //save transformed image to ouput-file
    image2.saveToFile(str3); 

    sf::Vector2u size = image.getSize();
    sf::Vector2u size2 = image2.getSize();
   
    sf::RenderWindow window1(sf::VideoMode(size.x, size.y), "Input File");
    sf::RenderWindow window2(sf::VideoMode(size2.x, size2.y), "Output File");
    sf::Texture texture; 
    texture.loadFromImage(image);

    sf::Texture texture2; 
    texture2.loadFromImage(image2);

    sf::Sprite sprite; 
    sprite.setTexture(texture); 

    sf::Sprite sprite2; 
    sprite2.setTexture(texture2); 

while (window1.isOpen() && window2.isOpen()) {
    sf::Event event;
    while (window1.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window1.close();
    }
    while (window2.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window2.close();
    }
    window1.clear();
    window1.draw(sprite);
    window1.display();
    window2.clear();
    window2.draw(sprite2);
    window2.display();
}

    return 0; 
}

void transform(sf::Image& image, FibLFSR* fib){ // transforms image using FibLFSR
 
    sf::Color p;
    sf::Vector2u size = image.getSize(); //figure out how big image is using getSize
    for(unsigned int x = 0; x < size.x; x++){
        for(unsigned int y = 0; y < size.y; y++){
            p = image.getPixel(x,y); 
            p.r = p.r ^ fib->generate(8);
            p.g = p.g ^ fib->generate(8); 
            p.b = p.b ^ fib->generate(8); 
            image.setPixel(x,y,p);
             
        }
    }
}
