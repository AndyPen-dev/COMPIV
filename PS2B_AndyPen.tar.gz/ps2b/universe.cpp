#include "universe.h"


CelestialBody::CelestialBody(){} //default constructor

CelestialBody::CelestialBody(double x, double y, double vX, double vY, double bodyMass, std::string imgFile){
// specify all the initial parameters (x,y position and velocity; mass; image filename)
    
    xPos = x; 
    yPos = y;
    xVel = vX; 
    yVel = vY; 
    mass = bodyMass; 
    img = imgFile; 

//load image into new Texture object;create a new Sprite w Texture 
    texture.loadFromFile(img);
    sprite.setTexture(texture);
    xPos = xPos / 100000000000; 
    yPos = yPos / 100000000000;
    sprite.setPosition(xPos, yPos); 
}


//void CelestialBody::spritePos(double viewScale){

   
//    sprite.setTexture(texture); 
//    xPos /= 1000000000.0;
 //   yPos /= 1000000000.0; 
 //   sprite.setPosition((xPos + viewScale), yPos + viewScale);

//}

void CelestialBody::draw(sf::RenderTarget& target, sf::RenderStates states) const{
     
  //  this.spritePos()
    target.draw(sprite, states); 

}

std::istream &operator>>(std::istream& in, CelestialBody& rhs){
    //read in all member variables
    in >> rhs.xPos >> rhs.yPos >> rhs.xVel >> rhs.yVel >>  rhs.mass >> rhs.img;
    return in; 
}



Universe::Universe(int planets, double rad){

    std::cin >> planets >> rad; 
    bodies = planets; 
    rad = radius; 
    std::cin >> xPos >> yPos >> xVel >> yVel >> mass >> img;
    CelestialBody(xPos, yPos, xVel, yVel, mass, img); 
    for(int i = 0; i < bodies; i++){
    std::shared_ptr<CelestialBody> ptr(new CelestialBody(xPos, yPos, xVel, yVel, mass, img));
    std::cin >> *ptr; 
    xPos = (xPos / rad) * -300 + 300; 
    yPos = (yPos / rad) * -300 + 300; 
    sPtr.push_back(ptr); 
    //std::cin >> *ptr; 


 }

//void Universe::newCBody(){

//for(int i = 0; i < bodies; i++){
//    std::shared_ptr<CelestialBody> ptr(new CelestialBody);
//    std::cin >> *ptr; 
 //   sPtr.push_back(ptr);
//}

}
void Universe::draw(sf::RenderTarget& target, sf::RenderStates states) const{
    for(int i = 0; i < bodies; i++){
        target.draw(*sPtr[i], states);
    }
}

//void Universe::setSpritePos(int){
  //  for(int i = 0; i < bodies; i++){
    //    sprite.setPosition();
    //}
//}


    


