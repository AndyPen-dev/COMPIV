﻿/**********************************************************************
 *  N-Body Simulation ps2b-readme.txt template
 **********************************************************************/

Name: Andy Pen
Hours to complete assignment:
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.

This assignment involves adding on to the previous ps2a assignment where the nbody file is read and the bodies are supposed to revoove around a fixated sun in a counter clockwise position based on the data given. The Universe class has to have a step function to calculate the forces, acceleration, velocity and new position. I have yet finished the function since I am still having trouble displaying the planets. I will have to use psX to make both ps2a and ps2b assignments to make up the credit. 
 **********************************************************************/





/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/




/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.

Previous readings from instructor 
 **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered.    

I haven’t got the planets to display yet, I believe something is wrong when the program tries to read in the nbody file.                 
 **********************************************************************/


/**********************************************************************
 *  List any other comments here.    

I will be using psX to make up both the ps2a and ps2b assignments.                                  
 **********************************************************************/

